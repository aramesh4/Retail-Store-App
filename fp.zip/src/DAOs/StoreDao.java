/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import javafx.scene.control.Alert;

/**
 *
 * @author Adarsh
 */
public class StoreDao {
    
    //Create connection class object whihc will be used in all the methods
    private Conections_Messages con_mes = new Conections_Messages();
    
    public ArrayList getAllStore(){
        
        ArrayList<String> storeIDList = new ArrayList<>();
        
        try {
                Connection con = DriverManager.getConnection("jdbc:mysql://www.papademas.net:3306/dbfp", "fpuser", "510");
                java.sql.Statement st = con.createStatement();
                String query = "select storeID from a20361171_store;";
                ResultSet rs = st.executeQuery(query);
                while(rs.next()){
                    String id = rs.getString(1);
                    storeIDList.add(id);
                }
        }catch(Exception e){
            con_mes.alertMessage(Alert.AlertType.ERROR, "Error Message", "Error while fetching StoreID's!!");
        }
        return storeIDList;

    }
    
}
