/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOs;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.SQLException;
import javafx.scene.control.Alert;

/**
 *
 * @author Adarsh
 */
public class Conections_Messages {

    //Connection object
//    private java.sql.Connection connection;
//    //Database connection parameters
//    private final String url = "jdbc:mysql://www.papademas.net:3306/dbfp";
//    private final String username = "fpuser";
//    private final String password = "510";
//    
//
//    public void setup() throws Exception {
//        try {
//            
//            connection = DriverManager.getConnection(url, username, password);
//            } catch (Exception e) {
//                System.out.println("Error creating connection to database: " + e);
//                System.exit(-1);
//        }
//
//            String sql = "CREATE TABLE usersA20361171 "
//                    + "(userid INTEGER not NULL AUTO_INCREMENT, "
//                    + " username VARCHAR(10), "
//                    + "userpassword VARCHAR(10)"
//                    + "admin CHAR"
//                    + "customer CHAR"
//                    + "lastname VARCHAR(20)"
//                    + "firstname VARCHAR(20)"
//                    + "emailid VARCHAR(20)"
//                    + "phonenumber VARCHAR(15)"
//                    + "address VARCHAR(150)"
//                    + "createdon DATE"
//                    + "lastupdated DATE"
//                    + " PRIMARY KEY ( userid ))";
//
//            statement.executeUpdate(sql);
//            
//        
//    }
//
    public void connect() {
//        try{
//        java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://www.papademas.net:3306/dbfp", "fpuser", "510");
//        }catch(Exception e){
//            alertMessage(Alert.AlertType.ERROR,"Login Failed", "Error while connecting to database!!!");
//        }
        }

    public void close() {
//        try{
//        java.sql.Connection con = null;
//        con.commit();
//        con.close();
//        }catch(Exception e){
//            alertMessage(Alert.AlertType.ERROR,"Login Failed", "Error while closing the database connection");
//        }
    }
    
    public void alertMessage(Alert.AlertType alerttype, String title, String message){
        Alert alert = new Alert(alerttype);
           alert.setTitle(title);
           alert.setHeaderText(null);
           alert.setContentText(message);
           alert.showAndWait();
    }
}
