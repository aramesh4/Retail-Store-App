/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;

/**
 *
 * @author Adarsh
 */
public class InventoryTableModel {
    
    private static StringProperty  productID;

    private static StringProperty  productName;
    
    private static StringProperty  productDesc;
    
    private static IntegerProperty availableQuantity;

    public InventoryTableModel(String productID, String productName, String productDesc, int availableQuantity) {
        this.productID = new SimpleStringProperty(productID);
       this.productName = new SimpleStringProperty(productName);
       this.productDesc = new SimpleStringProperty(productDesc);
       this.availableQuantity = new SimpleIntegerProperty(availableQuantity);
    }

    public InventoryTableModel() {
        }
    
    
 public String getProductID() {
        return productID.get();
    }

    public void setProductID(String firstName) {
        this.productID.set(firstName);
    }

    public StringProperty productIDProperty() {
        return productID;
    }   
 
    public String getProductName() {
        return productName.get();
    }

    public void setProductName(String firstName) {
        this.productName.set(firstName);
    }

    public StringProperty productNameProperty() {
        return productName;
    } 
    
    public String getProductDesc() {
        return productDesc.get();
    }

    public void setProductDesc(String firstName) {
        this.productDesc.set(firstName);
    }

    public StringProperty productDescProperty() {
        return productDesc;
    } 
    
    public int getAvailableQuantity() {
        return availableQuantity.get();
    }

    public void setAvailableQuantity(int postalCode) {
        this.availableQuantity.set(postalCode);
    }

    public IntegerProperty availableQuantityProperty() {
        return availableQuantity;
    }
}
