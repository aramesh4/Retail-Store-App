/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author Adarsh
 */
public class Store {
    
    private String storeID;
    private String storeName;
    private String location;
    private String phonenumber;
    private String emialID;

    public void Store(String storeID,String storeName,String location,String phonenumber,String emailID){
        this.storeID = storeID;
        this.storeName = storeName;
        this.location = location;
        this.phonenumber = phonenumber;
        this.emialID = emailID;        
    }
    
    /**
     * @return the storeID
     */
    public String getStoreID() {
        return storeID;
    }

    /**
     * @param storeID the storeID to set
     */
    public void setStoreID(String storeID) {
        this.storeID = storeID;
    }

    /**
     * @return the storeName
     */
    public String getStoreName() {
        return storeName;
    }

    /**
     * @param storeName the storeName to set
     */
    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    /**
     * @return the location
     */
    public String getLocation() {
        return location;
    }

    /**
     * @param location the location to set
     */
    public void setLocation(String location) {
        this.location = location;
    }

    /**
     * @return the phonennumber
     */
    public String getPhonenumber() {
        return phonenumber;
    }

    /**
     * @param phonennumber the phonennumber to set
     */
    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    /**
     * @return the emialID
     */
    public String getEmialID() {
        return emialID;
    }

    /**
     * @param emialID the emialID to set
     */
    public void setEmialID(String emialID) {
        this.emialID = emialID;
    }
    
}
